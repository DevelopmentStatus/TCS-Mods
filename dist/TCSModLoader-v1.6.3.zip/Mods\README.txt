﻿Place plugin ZIPs or supported asset ZIP/RAR archives directly here. Keep them compressed. Remove an archive and restart to restore underlying assets. See docs/ASSET_IMPORT.md.
