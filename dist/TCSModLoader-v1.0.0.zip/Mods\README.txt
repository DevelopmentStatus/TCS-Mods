﻿Drop supported TCS Mod Loader mod ZIP files directly into this folder. Do not extract them here. Restart the game to load them.
