﻿Place supported mod archives here and keep them compressed. See the loader README for installation and settings.
