# TCS First Person — experimental v0.3.7

v0.3.7 restores the native animated gun muzzle as each bolt's origin, including separate barrels for dual weapons. Both first-person modes retain camera-directed pitch/yaw and bypass native NPC target selection. Shots travel parallel to the camera's viewing direction from the muzzle; the small muzzle/camera offset can be visible at close range. No camera-origin spawning or crosshair convergence raycast is used. This supersedes the eye-origin behavior in v0.3.6. Build and direction tests passed; gameplay verification requires restart.

v0.3.6 adds camera-directed ranged shots in both first-person modes. The controlled player's native Bolt_Shoot call temporarily bypasses NPC/script target and interception branches, preserving other state and restoring the target fields after firing. Its final Bolt_Add call supplies the camera orientation and eye origin so shots follow the center crosshair, including vertical aim, without muzzle parallax. Other characters, orbit/original camera, melee and deflections retain native behavior. The override is gated on a fresh camera sample and focused active gameplay. Eye-origin shots are intentional; muzzle visuals remain native. Projectile gravity and weapon-specific effects remain native, so arcing explosives can deviate over distance. This supersedes earlier notes about retaining weapon auto-aim. Build/math checks passed; gameplay hit accuracy needs testing after restart.

v0.3.5 restores attachment to the evaluated animated skeleton in Animated Head mode. All three attachment-offset axes are gently smoothed in character space, then placed relative to the current player root. Vertical root smoothing remains; horizontal movement and mouse rotation remain immediate. The camera inherits attachment position but no animation rotation or roll. Head-local animation remains suppressed only in this mode. Stale attachment samples fall back to a stable eye offset. This replaces the fixed body anchor introduced in v0.3.4.

v0.3.4 changes Animated Head mode to a stable body-relative eye anchor. Camera position and orientation no longer inherit skeleton animation. Vertical root movement is gently smoothed with a frame-rate-independent filter; horizontal movement and mouse look remain immediate. Large vertical changes snap, and switching characters/modes or leaving gameplay resets smoothing. Head hiding, body peek, mode-specific head animation suppression and Q character switching remain available. This supersedes the animation-following camera behavior described in earlier release notes.

v0.3.3 removes camera roll in Animated Head mode while retaining the attachment position and viewing direction. Q now performs the nearby-character switch in Story mode as well as Free Play; Tab selects the previous character where cycling is permitted. The installer migrates the old default Q/Tab pair and preserves custom bindings.

v0.3.2 suppresses only the head bone's local animation in Animated Head mode. Its local transform is replaced by its rest transform under the still-animated parent, so body flips and movement remain inherited. Descendant attachments follow the stabilized head. The adjusted skeleton is a temporary render copy used before camera-pose capture and head hiding; the engine's original animated skeleton is never overwritten. All other modes, menus and disabled-camera states use the native head animation automatically. Regression tests cover head-local rotation/translation suppression, retained body flips, descendant attachment transforms and preservation of the original pose.

v0.3.1 corrects the animated head camera's 180-degree facing mismatch between the rendered character's reference frame and the camera. The correction is applied before animation rotation, preserving flips, local mouse-look limits and attachment positioning. Ordinary first person and orbit are unchanged.

v0.3 adds **Animated Head** after ordinary first person. It follows the head attachment's animated position and rotation, including flips, rolls and head tilts. Mouse look is composed within that moving frame; its vertical limits apply relative to the head, not world up. Defaults are 80 degrees up and 85 degrees down, adjustable with `LookUpDegrees` and `LookDownDegrees`. Ordinary first person stays upright. Both first-person modes retain head hiding, body peek and context-sensitive blocking/zoom. Characters without a usable head use orbit instead.

The head pose is captured before head hiding from the evaluated character render. The next camera update uses that pose, compensating for current character position and heading. This introduces roughly one rendered frame of animation delay. Stale poses, character/model changes and mirrored reflection renders are rejected; until a usable pose is available, the animated mode uses the ordinary first-person position and orientation. Mouse yaw/pitch is never read back from the animation, preventing animation rotations from accumulating into input drift.

v0.2.2 makes right mouse context-sensitive: lightsaber characters and melee characters with native block animations enter the game's held-guard stance while the button is held. Ranged characters retain first-person zoom. Guard takes priority over left-click attack; releasing right mouse releases the mod-owned guard. Jumping, hit reactions and interactions remain native. No invulnerability is added. Validate blocking/deflection against enemies after restart.

v0.2.1 fixes continuous spinning/downward drift by calculating differences between the game's accumulated low-16-bit mouse coordinates, including wraparound and capture resets. Both first person and orbit now follow mouse movement without holding a button. F6 releases mouse look/capture when needed. Regression checks cover stationary samples, forward/reverse wraparound, focus/capture resumption, unused high bits and device-origin jumps.

v0.2 provides configurable PC bindings across all three camera modes. Keyboard input replaces conflicting native gameplay bindings, while controller input and native menu navigation remain available. Existing configuration values are preserved when new default bindings are added.

v0.1.1 reads mouse motion from the game's native DirectInput polling function, preserving its calling convention and returned state. This replaces the Windows raw-input event path that failed to drive camera rotation. Restart to load this update. Runtime logs now include `mousePolls` and `mouseMotionSamples` to verify input delivery.

Custom camera/controller mod for the user's Steam PC installation of LEGO Star Wars: The Complete Saga. Built for the executable with SHA-256 `085688e73561c61f4619fcf1f3006c56425ca365e80ea5fc0175bab334cec671`.

## Controls

- **C:** cycle first person → animated head camera → third-person orbit → original game camera.
- First person uses mouse look, hides the controlled character's head and its attached skeleton joints, and keeps the body visible. Looking down gradually shifts the camera outward a little.
- Characters without a declared head joint, including GonkDroid, automatically use third-person orbit when first person is selected.
- In third person, **move the mouse** to orbit without holding a button. F6 frees the cursor; press it again to resume mouse look. Mouse wheel changes orbit distance.
- **WASD:** camera-relative movement. **Shift:** walk. Diagonal movement is normalized.
- **Left mouse:** attack/fire/melee. **Right mouse:** hold to block with a lightsaber/melee character, or narrow the first-person view with a ranged character. Blocking takes priority over left mouse while held. Orbit follows mouse movement automatically. Blaster shots follow the crosshair in both first-person modes; other camera modes retain native targeting.
- **Space:** jump; press again for the character's native double-jump/hover action where supported.
- **E or F:** native special ability/interact/build/Force action, depending on the character and context; hold when the original action requires it.
- **Q:** native nearby-character switch/tag action. **Tab/R:** previous/next character where the game permits cycling.
- **Mouse wheel:** cycle characters in first person or original camera; zoom the orbit camera in third person.
- **Esc:** native pause/back navigation. Menus retain their original controls.
- The above keyboard/mouse controls work in all four camera modes. A controller retains native inputs when keyboard/mouse gameplay input is inactive.
- **F5:** enable/disable the custom camera. **F6:** release/enable mouse look. **F7:** recenter.

The mod opens a 1280×720 window. Adjust display size, horizontal field of view, mouse sensitivity and control options in `TCSFirstPerson.ini` before starting the game.

Rebind controls in the INI's `[Bindings]` section. Supported names are single letters/digits, Mouse1–Mouse5, Space, Tab, Shift, Ctrl, Alt, Enter, Up/Down/Left/Right, F1–F12 and None. Keep bindings distinct; F5–F7 are reserved for camera troubleshooting. Set `ModernControls=0` to restore native gameplay bindings. This game has no universal crouch, reload or sprint action, so the mod does not assign misleading keys to those actions.

## Install and remove

Run `Install-Mod.ps1` from this folder. It installs `build/Release/d3d9.dll` and the INI into the selected game directory, retaining an existing DLL in a timestamped backup. Restart the game to load the new version. If Windows locks the loaded DLL, close the game and run the installer again. The installer never injects into a running process.

To remove this mod, close the game and move `d3d9.dll` out of the game directory. The game executable, archives and saves are not changed by this mod's installer. Restore a previous proxy DLL from the backup if needed.

## Validation and current limits

Windowed initialization was observed successfully before the camera/controller changes. The first-person build compiles as a 32-bit Windows DLL. Automated checks cover camera orientation, horizontal/vertical FOV conversion, smooth look-down offsets, body framing and head-joint ancestry.

Each updated camera/controller build requires testing after restart: check the four C camera modes, stable animated-mode eye height, immediate mouse look, jumps/landings and reset transitions, Gonk orbit fallback, humanoid head hiding, body visibility while looking down, WASD strafing, blocking/attacking, character changes, menus and cutscenes. Runtime diagnostics are written to `TCSFirstPerson.log`; head hiding reports `hiddenHeadDraws`, while animated attachment use reports `HEAD`, `animatedHead=1` and `headPoseSamples`.

This is a camera and native-input mod, not a replacement combat engine. Original auto-aim and weapon behavior remain. Orbit wall collision and every character's extra hats/accessories are not yet verified. Single-player is the current target.

## Build

Use Visual Studio 2022 C++ tools and CMake: configure for Win32, build Release, then run CTest. The deliverable has no external mod framework dependency. `research/` contains reference sources and local analysis files and is not part of the installable mod.

Research references: [BrickBench](https://github.com/BrickBench/BrickBench), [Traveller](https://github.com/BrickBench/Traveller), and the [Android decompilation](https://github.com/opensagadev/saga). PC addresses and layout were checked against the user's executable and read-only runtime data rather than assumed from the Android port. REA camera evidence: `ev_6aa8d98950ab238f7108b940389a9ecd6d9c0c688ae69dd320928b04621d3d8e`; character renderer: `ev_bb86afaccd454510a54be79ebcc74ae2cf452343d7824e48c4bd6a054b218628`.
