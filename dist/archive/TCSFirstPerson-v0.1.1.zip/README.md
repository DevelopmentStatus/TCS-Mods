# TCS First Person — experimental v0.1.1

v0.1.1 reads mouse motion from the game's native DirectInput polling function, preserving its calling convention and returned state. This replaces the Windows raw-input event path that failed to drive camera rotation. Restart to load this update. Runtime logs now include `mousePolls` and `mouseMotionSamples` to verify input delivery.

Custom camera/controller mod for the user's Steam PC installation of LEGO Star Wars: The Complete Saga. Built for the executable with SHA-256 `085688e73561c61f4619fcf1f3006c56425ca365e80ea5fc0175bab334cec671`.

## Controls

- **C:** cycle first person → third-person orbit → original game camera.
- First person uses mouse look, hides the controlled character's head and its attached skeleton joints, and keeps the body visible. Looking down gradually shifts the camera outward a little.
- Characters without a declared head joint, including GonkDroid, automatically use third-person orbit when first person is selected.
- In third person, **hold right mouse** to orbit; release it to free the cursor. Mouse wheel changes orbit distance.
- Modern controls: **WASD** movement, **left mouse** attack, **Space** jump, **E** ability/interact, **Q** switch character. Existing game controls remain available.
- **F5:** enable/disable the custom camera. **F6:** release/enable mouse look. **F7:** recenter.

The mod opens a 1280×720 window. Adjust display size, horizontal field of view, mouse sensitivity and control options in `TCSFirstPerson.ini` before starting the game.

## Install and remove

Run `Install-Mod.ps1` from this folder. It installs `build/Release/d3d9.dll` and the INI into the selected game directory, retaining an existing DLL in a timestamped backup. Restart the game to load the new version. If Windows locks the loaded DLL, close the game and run the installer again. The installer never injects into a running process.

To remove this mod, close the game and move `d3d9.dll` out of the game directory. The game executable, archives and saves are not changed by this mod's installer. Restore a previous proxy DLL from the backup if needed.

## Validation and current limits

Windowed initialization was observed successfully before the camera/controller changes. The first-person build compiles as a 32-bit Windows DLL. Automated checks cover camera orientation, horizontal/vertical FOV conversion, smooth look-down offsets, body framing and head-joint ancestry.

The camera/controller build still requires testing after restart: check C mode cycling, Gonk RMB orbit, humanoid head hiding, body visibility while looking down, WASD strafing, attacking, character changes, menus and cutscenes. Runtime diagnostics are written to `TCSFirstPerson.log`; head hiding reports `hiddenHeadDraws`.

This is a camera and native-input mod, not a replacement combat engine. Original auto-aim and weapon behavior remain. Orbit wall collision and every character's extra hats/accessories are not yet verified. Single-player is the current target.

## Build

Use Visual Studio 2022 C++ tools and CMake: configure for Win32, build Release, then run CTest. The deliverable has no external mod framework dependency. `research/` contains reference sources and local analysis files and is not part of the installable mod.

Research references: [BrickBench](https://github.com/BrickBench/BrickBench), [Traveller](https://github.com/BrickBench/Traveller), and the [Android decompilation](https://github.com/opensagadev/saga). PC addresses and layout were checked against the user's executable and read-only runtime data rather than assumed from the Android port. REA camera evidence: `ev_6aa8d98950ab238f7108b940389a9ecd6d9c0c688ae69dd320928b04621d3d8e`; character renderer: `ev_bb86afaccd454510a54be79ebcc74ae2cf452343d7824e48c4bd6a054b218628`.
