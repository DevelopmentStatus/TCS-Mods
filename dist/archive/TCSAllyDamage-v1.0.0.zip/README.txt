TCS ALLY DAMAGE 1.0.0

AI-controlled party members and native friendly AI use player-style damage
flags, allowing their existing attacks to damage enemies. Normal weapon damage,
shields, blocking, scripted invulnerability and boss rules still apply.
The mod changes damage eligibility; it does not change AI attack frequency,
aiming, movement or scripted combat behavior.

Requires TCS Mod Loader and the supported 32-bit Steam PC executable of
LEGO Star Wars: The Complete Saga. Can be used with TCS First Person.

INSTALL
Close the game. Put TCSAllyDamage-v1.0.0.zip directly in the game's Mods folder.
Keep it zipped. Start the game, then open:
Pause > Mod Settings > TCS Ally Damage > AI allies deal damage.
Enabled by default. Settings persist in Mods/Config/tcs.allydamage.ini.

REMOVE
Close the game and remove TCSAllyDamage-v1.0.0.zip from Mods.

VALIDATION
Built for x86 Release. Automated checks execute the original PC hit-flag routine
and the production DLL hooks in an isolated synthetic game host. Checks cover
ally damage, unchanged enemy flags, human takeover, in-flight toggle behavior,
same-faction projectile filtering and clean shutdown. The synthetic host may
skip if Windows has already allocated one of the fixed game addresses.
Actual in-game combat has not yet been verified.
