﻿# TCS First Person and Mod Loader

A native camera and input mod for the validated 32-bit Steam PC build of LEGO Star Wars: The Complete Saga.

## Install

Install the separate **TCS Mod Loader** once using `Install-Mod.ps1` from its package, or copy `d3d9.dll` beside `LEGOStarWarsSaga.exe`. Then place mod ZIP archives in `<game folder>\Mods` and restart. For the ready-to-use setup, put both `TCSFirstPerson-v0.3.11.zip` and `TCSModernOptions-v0.4.0.zip` there. The loader extracts and loads each archive independently.

TCS Modern Options adds the **F10** menu with Video, Gameplay and Mods sections. Display changes can be reverted by pressing Escape or waiting for the 15-second confirmation timer. Loader settings are saved to `TCSModLoader.ini`; per-mod options live in `Mods\Config`. See [MODDING.md](MODDING.md) for package installation, removal and plugin details.

## First Person controls

- **C:** cycle first person → animated head camera → third-person orbit → original game camera.
- First person hides the controlled character's head and attached skeleton joints while keeping the body visible. Characters without a usable head, including GonkDroid, use orbit fallback.
- **WASD:** camera-relative movement; **Shift:** walk; diagonal movement is normalized.
- **Left mouse:** attack/fire/melee. **Right mouse:** block with a lightsaber/melee character or narrow the first-person view for ranged characters.
- **Space:** jump; **E or F:** native special ability/interact/build/Force action.
- **Q:** nearby-character switch/tag. **Tab/R:** previous/next character when permitted.
- **Mouse wheel:** cycle characters in first person or original camera; zoom orbit. **F5:** toggle custom camera; **F6:** release/resume mouse look; **F7:** recenter.
- Controller input and native menus remain available. The mod does not invent crouch, reload or sprint actions.

## Remove

Close the game, then delete the mod ZIPs from `Mods`. Remove the loader by restoring the `d3d9.dll.before-tcs-mod-loader.*.bak` file retained by the installer. Generated `Mods\Loaded` extraction folders can also be deleted while the game is closed. Config files remain under `Mods\Config` unless you choose to remove them.

## Build and validation

Build with Visual Studio 2022 C++ tools and CMake for Win32 Release, then run CTest. The current suite checks camera math and the plugin registration contracts. Loader/ZIP startup, overlay navigation, keyboard/controller behavior and real display changes still require verification in the game.
